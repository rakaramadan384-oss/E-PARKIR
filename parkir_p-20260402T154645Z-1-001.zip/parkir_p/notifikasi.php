<?php
// Mencegah error jika file di-include berkali-kali
if (!function_exists('showMessage')) {
    
    function showMessage($type, $title, $text, $redirect = null) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <style>
                body { 
                    background-color: #121212; 
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                }
                .swal2-popup { font-family: inherit !important; }
            </style>
        </head>
        <body>
        <script>
            // Pastikan script berjalan setelah DOM siap
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: '<?php echo $type; ?>',
                    title: '<span style="color:#ffcc00; text-transform: uppercase;"><?php echo $title; ?></span>',
                    html: '<div style="color:#ffffff"><?php echo $text; ?></div>',
                    background: '#1a1a1a',
                    confirmButtonColor: '#ffcc00',
                    confirmButtonText: '<strong style="color:#000">OKE</strong>',
                    allowOutsideClick: false,
                    backdrop: `rgba(0,0,0,0.9)`
                }).then((result) => {
                    if (result.isConfirmed) {
                        <?php if ($redirect): ?>
                            window.location.href = '<?php echo $redirect; ?>';
                        <?php endif; ?>
                    }
                });
            });
        </script>
        </body>
        </html>
        <?php
        exit(); 
    }
}
?>