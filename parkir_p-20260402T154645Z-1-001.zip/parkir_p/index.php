<?php
session_start();

// Jika belum login, paksa ke halaman login
if (!isset($_SESSION['status_login'])) {
    header("Location: login.php");
    exit();
}

// Jika sudah login, lempar ke dashboard yang sesuai
$level = $_SESSION['level'];

if ($level == 'admin') {
    header("Location: admin_dashboard.php");
} elseif ($level == 'petugas_masuk') {
    header("Location: petugas_input.php");
} elseif ($level == 'petugas_keluar') {
    header("Location: petugas_keluar.php");
} elseif ($level == 'owner') {
    header("Location: owner_laporan.php");
} else {
    // Jika level tidak jelas, logout
    header("Location: logout.php");
}
exit();
?>