<?php
session_start();
include 'config.php';
include_once 'notifikasi.php';

// Proteksi halaman: Hanya petugas yang boleh masuk
if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'petugas_keluar') {
    header("Location: index.php");
    exit();
}

include 'header.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <style>
        :root {
            --parking-yellow: #ffcc00;
            --parking-black: #1a1a1a;
            --parking-dark: #121212;
            --parking-blue: #0d6efd; 
            --parking-red: #ff4444;
        }

        body {
            background-color: var(--parking-dark);
            color: #ffffff; 
            background-image: radial-gradient(circle at 2px 2px, #252525 1px, transparent 0);
            background-size: 40px 40px;
        }

        /* Card Styling */
        .card-custom {
            background: var(--parking-black);
            border: none;
            border-radius: 15px;
            overflow: hidden;
        }

        .card-header-checkout {
            background: transparent;
            border-bottom: 1px solid #333;
            padding: 25px;
        }

        /* Input Pencarian Kontras */
        .label-yellow { color: var(--parking-yellow); letter-spacing: 1px; font-weight: bold; }
        
        .input-search {
            background-color: #ffffff !important;
            color: #000000 !important;
            border: 4px solid var(--parking-red) !important; /* Merah untuk tanda keluar/stop */
            font-family: 'Courier New', Courier, monospace;
            letter-spacing: 5px;
            font-weight: 900;
        }

        /* Tombol Cek */
        .btn-check {
            background-color: var(--parking-yellow);
            color: #000;
            border: none;
            font-weight: 800;
            text-transform: uppercase;
            transition: 0.3s;
        }
        .btn-check:hover {
            background-color: #e6b800;
            transform: scale(1.02);
        }

        /* Table Tema Dashboard */
        .table-container {
            background-color: #ffffff; 
            border-radius: 10px;
            overflow: hidden;
            margin-top: 10px;
        }

        .table thead th {
            background-color: #f8f9fa !important;
            color: #333 !important;
            border-bottom: 3px solid var(--parking-yellow);
            text-transform: uppercase;
            font-size: 0.8rem;
        }

        .table tbody td {
            color: #000000 !important; 
            font-weight: 500;
        }

        .plat-badge {
            background-color: #eee;
            padding: 5px 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-family: monospace;
        }

        .parking-stripe {
            height: 10px;
            background: repeating-linear-gradient(-45deg, var(--parking-yellow), var(--parking-yellow) 10px, var(--parking-black) 10px, var(--parking-black) 20px);
        }
    </style>
</head>
<body>

<div class="container mt-4 pb-5">
    <div class="row mb-4">
        <div class="col-md-12 text-center text-md-start">
            <h2 class="fw-bold"><i class="bi bi-box-arrow-right text-danger me-2"></i> POS KELUAR</h2>
            <p class="text-secondary">Scan tiket atau ketik nomor plat untuk memproses pembayaran.</p>
        </div>
    </div>

    <div class="row justify-content-center mb-5">
        <div class="col-md-10">
            <div class="card card-custom shadow-lg">
                <div class="card-header-checkout text-center">
                    <h4 class="mb-0 fw-bold text-white">CHECK-OUT KENDARAAN</h4>
                </div>
                <div class="card-body p-4 p-md-5">
                    <form action="proses_keluar.php" method="GET">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-9">
                                <label class="form-label label-yellow fs-5">KODE TIKET / NOMOR PLAT</label>
                                <input type="text" name="search" 
                                       id="input_search"
                                       class="form-control form-control-lg text-center fs-2 input-search" 
                                       placeholder="B 1234 ABC" 
                                       style="height: 90px;"
                                       oninput="this.value = this.value.toUpperCase()"
                                       required autofocus>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-check btn-lg w-100 shadow" style="height: 90px;">
                                    <i class="bi bi-receipt me-2 fs-4"></i><br>CEK & BAYAR
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="parking-stripe"></div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card card-custom shadow-sm">
                <div class="card-header bg-transparent d-flex justify-content-between align-items-center py-3">
                    <h5 class="mb-0 fw-bold text-white"><i class="bi bi-clock-history me-2 text-warning"></i> AKTIVITAS HARI INI</h5>
                    <span class="badge bg-dark border border-secondary px-3 py-2">
                         <?= date('H:i') ?> WIB
                    </span>
                </div>
                <div class="card-body">
                    <div class="table-container shadow-sm">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead>
                                    <tr>
                                        <th class="ps-3">No. Plat</th>
                                        <th>Jenis</th>
                                        <th>Waktu Masuk</th>
                                        <th>Waktu Keluar</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $query = "SELECT t.*, k.jenis_kendaraan 
                                              FROM tb_transaksi t
                                              LEFT JOIN tb_kendaraan k ON t.id_kendaraan = k.id_kendaraan
                                              WHERE DATE(t.waktu_masuk) = CURDATE() 
                                              ORDER BY t.id_transaksi DESC LIMIT 8";
                                    $res = mysqli_query($conn, $query);

                                    if (mysqli_num_rows($res) > 0) {
                                        while ($row = mysqli_fetch_assoc($res)) {
                                            $is_keluar = ($row['status'] == 'keluar');
                                            $jenis = strtolower($row['jenis_kendaraan'] ?? 'motor');
                                    ?>
                                    <tr>
                                        <td class="ps-3 fw-bold text-uppercase">
                                            <span class="plat-badge"><?= $row['plat_nomor'] ?></span>
                                        </td>
                                        <td>
                                            <?php if($jenis == 'motor'): ?>
                                                <span class="text-info"><i class="bi bi-bicycle me-1"></i> Motor</span>
                                            <?php elseif($jenis == 'mobil'): ?>
                                                <span class="text-primary"><i class="bi bi-car-front me-1"></i> Mobil</span>
                                            <?php else: ?>
                                                <span class="text-secondary"><i class="bi bi-truck me-1"></i> <?= $jenis ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= date('H:i', strtotime($row['waktu_masuk'])) ?></td>
                                        <td><?= $is_keluar ? date('H:i', strtotime($row['waktu_keluar'])) : '<span class="text-muted italic">--:--</span>' ?></td>
                                        <td class="text-center">
                                            <?php if($is_keluar): ?>
                                                <span class="badge bg-success-subtle text-success border border-success rounded-pill px-3">Selesai</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning-subtle text-warning border border-warning rounded-pill px-3">Parkir</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php 
                                        } 
                                    } else {
                                        echo "<tr><td colspan='5' class='text-center py-4 text-dark'>Belum ada aktivitas hari ini.</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="parking-stripe"></div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('input_search').addEventListener('keyup', function() {
        this.value = this.value.toUpperCase();
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>