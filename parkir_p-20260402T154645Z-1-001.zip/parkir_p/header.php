<?php
// Pastikan session sudah dimulai di file yang memanggil header ini
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .navbar-custom { background-color: #2c3e50; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom mb-4 shadow">
    <div class="container">
        <a class="navbar-brand font-weight-bold" href="#">PARKIR-IN</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <?php if($_SESSION['level'] == 'admin'): ?>
                    <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="admin_tarif.php">Tarif</a></li>
                    <li class="nav-item"><a class="nav-link" href="admin_user.php">User</a></li>
                <?php elseif($_SESSION['level'] == 'petugas_masuk'): ?>
                    <li class="nav-item"><a class="nav-link" href="petugas_input.php">Masuk</a></li>
                <?php elseif($_SESSION['level'] == 'petugas_keluar'): ?>
                    <li class="nav-item"><a class="nav-link" href="petugas_keluar.php">Keluar</a></li>
                <?php elseif($_SESSION['level'] == 'owner'): ?>
                    <li class="nav-item"><a class="nav-link" href="owner_laporan.php">Laporan Pendapatan</a></li>
                <?php endif; ?>
            </ul>
            <span class="navbar-text me-3 text-light">
                Halo, <strong><?= $_SESSION['nama'] ?></strong> (<?= ucfirst($_SESSION['level']) ?>)
            </span>
            <a href="logout.php" class="btn btn-outline-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>