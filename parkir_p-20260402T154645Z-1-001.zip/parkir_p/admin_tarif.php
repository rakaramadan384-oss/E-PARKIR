<?php
include 'config.php';
include_once 'notifikasi.php';

session_start();

// Proteksi halaman
if (!isset($_SESSION['level']) || $_SESSION['level'] != 'admin') {
    header("location: login.php");
    exit();
}

// Proses Update
if (isset($_POST['update_tarif'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id_tarif']);
    $harga = mysqli_real_escape_string($conn, $_POST['harga']);
    
    $query = mysqli_query($conn, "UPDATE tb_tarif SET tarif_per_jam = '$harga' WHERE id_tarif = '$id'");
    
    if ($query) {
        echo "<script>alert('Tarif Berhasil Diubah!'); window.location='pengaturan_tarif.php';</script>";
    }
}

$tarif = mysqli_query($conn, "SELECT * FROM tb_tarif");
include 'header.php'; 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <style>
        :root {
            --parking-yellow: #ffcc00;
            --parking-black: #1a1a1a;
            --parking-dark: #121212;
        }

        body {
            background-color: var(--parking-dark);
            color: #ffffff; 
            background-image: radial-gradient(circle at 2px 2px, #252525 1px, transparent 0);
            background-size: 40px 40px;
        }

        .card-custom {
            background: var(--parking-black);
            border: none;
            border-radius: 12px;
            overflow: hidden;
        }

        .card-header-parking {
            background: transparent;
            border-bottom: 1px solid #333;
            padding: 20px;
        }

        /* Container Tabel Putih agar Teks Hitam Jelas */
        .table-container {
            background-color: #ffffff; 
            margin: 0 20px 20px 20px;
            border-radius: 8px;
            overflow: hidden;
        }

        .table {
            margin-bottom: 0;
            color: #000000 !important;
        }

        .table thead th {
            background-color: #f8f9fa !important;
            color: #333 !important;
            border-bottom: 3px solid var(--parking-yellow);
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 1px;
            padding: 15px;
        }

        .table tbody td {
            color: #000000 !important;
            font-weight: 500;
            padding: 15px;
        }

        /* Styling Input dalam Tabel */
        .input-group-text {
            background-color: #eee;
            border: 1px solid #ddd;
            color: #333;
            font-weight: bold;
        }

        .form-control-parking {
            border: 1px solid #ddd;
            font-weight: bold;
        }

        .form-control-parking:focus {
            border-color: var(--parking-yellow);
            box-shadow: 0 0 0 0.2rem rgba(255, 204, 0, 0.25);
        }

        /* Tombol Update Kuning */
        .btn-update {
            background-color: var(--parking-yellow);
            color: #000;
            border: none;
            font-weight: bold;
            text-transform: uppercase;
            transition: 0.3s;
        }

        .btn-update:hover {
            background-color: #e6b800;
            color: #000;
            transform: scale(1.05);
        }

        .parking-stripe {
            height: 8px;
            background: repeating-linear-gradient(-45deg, var(--parking-yellow), var(--parking-yellow) 10px, var(--parking-black) 10px, var(--parking-black) 20px);
        }

        .text-warning-custom {
            color: var(--parking-yellow) !important;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-custom shadow-lg">
                <div class="card-header-parking">
                    <h5 class="mb-0 fw-bold text-white">
                        <i class="bi bi-gear-fill me-2 text-warning-custom"></i> PENGATURAN TARIF PARKIR
                    </h5>
                    <p class="text-secondary small mb-0 mt-1">Sesuaikan biaya parkir berdasarkan jenis kendaraan.</p>
                </div>

                <div class="table-container">
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th class="ps-4">Jenis Kendaraan</th>
                                    <th>Tarif per Jam</th>
                                    <th class="text-center">Konfigurasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($t = mysqli_fetch_assoc($tarif)): ?>
                                <tr>
                                    <form method="POST">
                                        <td class="ps-4">
                                            <span class="text-dark fw-bold">
                                                <i class="bi bi-car-front me-2"></i><?= strtoupper($t['jenis_kendaraan']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="input-group input-group-sm" style="max-width: 180px;">
                                                <span class="input-group-text">Rp</span>
                                                <input type="number" name="harga" class="form-control form-control-parking" value="<?= $t['tarif_per_jam'] ?>" required>
                                                <input type="hidden" name="id_tarif" value="<?= $t['id_tarif'] ?>">
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <button type="submit" name="update_tarif" class="btn btn-update btn-sm px-4">
                                                <i class="bi bi-arrow-repeat me-1"></i> Update
                                            </button>
                                        </td>
                                    </form>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="px-4 pb-2">
                    <p class="text-secondary small italic">
                        <i class="bi bi-info-circle me-1"></i> Perubahan tarif akan langsung diterapkan pada sistem perhitungan biaya otomatis.
                    </p>
                </div>
                
                <div class="parking-stripe"></div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>