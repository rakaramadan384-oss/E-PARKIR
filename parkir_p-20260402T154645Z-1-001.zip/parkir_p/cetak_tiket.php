<?php
include 'config.php';
include_once 'notifikasi.php';

$kode = $_GET['kode'];
$q = mysqli_query($conn, "SELECT * FROM tb_transaksi WHERE kode_tiket = '$kode'");
$d = mysqli_fetch_assoc($q);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cetak Tiket</title>
    <style>
        body { font-family: 'Courier New', Courier, monospace; width: 250px; }
        .text-center { text-align: center; }
        hr { border-top: 1px dashed black; }
    </style>
</head>
<body onload="window.print()">
    <div class="text-center">
        <h3>PARKIR SMART</h3>
        <p>Jl. Sudirman No. 123</p>
        <hr>
        <h2><?= $d['kode_tiket'] ?></h2>
        <p>Plat: <?= $d['plat_nomor'] ?></p>
        <p>Masuk: <?= $d['waktu_masuk'] ?></p>
        <hr>
        <p>Simpan tiket ini dengan baik</p>
    </div>
</body>
</html>