<?php
include 'config.php';
include_once 'notifikasi.php';
session_start();

// Proteksi
if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'petugas_keluar') {
    header("Location: index.php");
    exit();
}

$search = mysqli_real_escape_string($conn, $_GET['search']);

// Ambil data transaksi dan tarif sesuai jenis kendaraan
$query = "SELECT t.*, a.nama_area, tr.tarif_per_jam, tr.jenis_kendaraan
          FROM tb_transaksi t
          JOIN tb_area a ON t.id_area = a.id_area
          JOIN tb_tarif tr ON a.jenis_kendaraan = tr.jenis_kendaraan
          WHERE (t.kode_tiket = '$search' OR t.plat_nomor = '$search') AND t.status = 'masuk'";

$res = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($res);

if (!$data) {
    echo "<script>alert('Data tidak ditemukan atau kendaraan sudah keluar!'); window.location='petugas_keluar.php';</script>";
    exit;
}

// Logika Hitung Waktu (WIB)
$masuk = new DateTime($data['waktu_masuk']);
$sekarang = new DateTime(); // Sesuai timezone Jakarta di config
$interval = $masuk->diff($sekarang);

// Hitung total jam (pembulatan ke atas)
$durasi_jam = $interval->h + ($interval->days * 24);
$durasi_menit = $interval->i;

// Aturan: Jika lebih dari 10 menit, hitung 1 jam tambahan, minimal 1 jam.
if ($durasi_menit > 10 || $durasi_jam == 0) {
    $durasi_jam++;
}

$total_bayar = $durasi_jam * $data['tarif_per_jam'];

// Update database saat tombol bayar diklik
if (isset($_POST['bayar'])) {
    $id_t = $data['id_transaksi'];
    $waktu_keluar = date("Y-m-d H:i:s");
    $id_area = $data['id_area'];

    $upd = "UPDATE tb_transaksi SET 
            waktu_keluar = '$waktu_keluar', 
            durasi_jam = '$durasi_jam', 
            total_bayar = '$total_bayar', 
            status = 'keluar' 
            WHERE id_transaksi = '$id_t'";
    
    if (mysqli_query($conn, $upd)) {
        // Kurangi jumlah kendaraan terisi di area tersebut
        mysqli_query($conn, "UPDATE tb_area SET terisi = terisi - 1 WHERE id_area = '$id_area'");
        echo "<script>alert('Pembayaran Berhasil! Kendaraan silakan keluar.'); window.location='petugas_keluar.php';</script>";
    }
}

include 'header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-dark text-white text-center py-3">
                    <h4 class="mb-0">RINGKASAN PEMBAYARAN</h4>
                    <small class="text-warning">Kode Tiket: <?= $data['kode_tiket'] ?></small>
                </div>
                <div class="card-body p-4">
                    <div class="text-center mb-4">
                        <h1 class="display-4 fw-bold text-success">Rp <?= number_format($total_bayar, 0, ',', '.') ?></h1>
                        <span class="badge bg-light text-dark border"><?= ucfirst($data['jenis_kendaraan']) ?> - <?= $data['nama_area'] ?></span>
                    </div>

                    <table class="table table-borderless fs-5">
                        <tr>
                            <td class="text-muted">No. Plat</td>
                            <td class="text-end fw-bold text-uppercase"><?= $data['plat_nomor'] ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Waktu Masuk</td>
                            <td class="text-end small"><?= date('d M Y, H:i', strtotime($data['waktu_masuk'])) ?> WIB</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Waktu Keluar</td>
                            <td class="text-end small"><?= date('d M Y, H:i') ?> WIB</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Durasi Parkir</td>
                            <td class="text-end fw-bold"><?= $durasi_jam ?> Jam</td>
                        </tr>
                        <tr>
                            <td colspan="2"><hr></td>
                        </tr>
                        <tr class="fs-6 italic">
                            <td class="text-muted small">* Tarif per jam</td>
                            <td class="text-end small">Rp <?= number_format($data['tarif_per_jam'], 0, ',', '.') ?></td>
                        </tr>
                    </table>

                    <div class="row g-2 mt-3">
                        <div class="col-6">
                            <a href="petugas_keluar.php" class="btn btn-outline-secondary btn-lg w-100">BATAL</a>
                        </div>
                        <div class="col-6">
                            <form method="POST">
                                <button name="bayar" class="btn btn-success btn-lg w-100 shadow">
                                    <i class="bi bi-cash-stack"></i> BAYAR
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-center text-muted small py-3">
                    Pastikan nominal pembayaran sesuai sebelum konfirmasi.
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>