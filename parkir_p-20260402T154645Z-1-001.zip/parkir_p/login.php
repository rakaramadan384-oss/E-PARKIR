<?php session_start(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Parkir Modern</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root {
            --parking-yellow: #ffcc00;
            --parking-black: #1a1a1a;
            --parking-dark: #121212;
        }

        body {
            background-color: var(--parking-dark);
            /* Tekstur aspal halus sebagai latar belakang */
            background-image: radial-gradient(circle at 2px 2px, #252525 1px, transparent 0);
            background-size: 40px 40px;
            height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        }

        .card-login {
            background: var(--parking-black);
            border: none;
            border-top: 5px solid var(--parking-yellow);
            border-radius: 12px;
            color: white;
            transition: transform 0.3s ease;
        }

        .card-login:hover {
            transform: translateY(-5px);
        }

        .login-icon {
            font-size: 3rem;
            color: var(--parking-yellow);
            margin-bottom: 10px;
        }

        .form-control {
            background-color: #2a2a2a;
            border: 1px solid #333;
            color: white;
            padding: 12px;
        }

        .form-control:focus {
            background-color: #333;
            border-color: var(--parking-yellow);
            box-shadow: 0 0 0 0.25 margin-rgba(255, 204, 0, 0.25);
            color: white;
        }

        .btn-parking {
            background-color: var(--parking-yellow);
            color: var(--parking-black);
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 12px;
            border: none;
            transition: all 0.3s;
        }

        .btn-parking:hover {
            background-color: #e6b800;
            color: black;
            transform: scale(1.02);
        }

        .parking-stripe {
            height: 10px;
            background: repeating-linear-gradient(
                -45deg,
                var(--parking-yellow),
                var(--parking-yellow) 10px,
                var(--parking-black) 10px,
                var(--parking-black) 20px
            );
            border-radius: 0 0 12px 12px;
        }

        label {
            color: #aaa;
            font-size: 0.9rem;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4 px-4">
            <div class="card card-login shadow-lg">
                <div class="card-body p-5">
                    <div class="text-center mb-4">
                        <div class="login-icon">
                            <i class="bi bi-p-square-fill"></i>
                        </div>
                        <h3 class="fw-bold mb-0">E-PARKING</h3>
                        <p class="text-muted small">Silakan masuk ke sistem</p>
                    </div>

                    <form action="cek_login.php" method="POST">
                        <div class="mb-3">
                            <label><i class="bi bi-person me-2"></i>Username</label>
                            <input type="text" name="username" class="form-control" placeholder="Masukkan username" required>
                        </div>
                        <div class="mb-4">
                            <label><i class="bi bi-lock me-2"></i>Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
                        </div>
                        <button type="submit" class="btn btn-parking w-100 shadow-sm">
                            Masuk Sekarang <i class="bi bi-arrow-right-short"></i>
                        </button>
                    </form>
                </div>
                <div class="parking-stripe"></div>
            </div>
            <p class="text-center mt-4 text-muted small">
                &copy; <?= date('Y') ?> Management Parking System. 
            </p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>