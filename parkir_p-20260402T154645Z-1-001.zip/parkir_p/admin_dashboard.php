<?php
session_start();
include 'config.php';
include_once 'notifikasi.php';

// Proteksi halaman: Hanya admin yang boleh masuk
if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'admin') {
    header("Location: index.php");
    exit();
}

include 'header.php';

// Query Statistik
$count_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM tb_user"))['total'];
$q_pendapatan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_bayar) as total FROM tb_transaksi"));
$total_pendapatan = $q_pendapatan['total'] ?? 0;
$kendaraan_aktif = mysqli_num_rows(mysqli_query($conn, "SELECT id_transaksi FROM tb_transaksi WHERE status='masuk'"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        :root {
            --parking-yellow: #ffcc00;
            --parking-black: #1a1a1a;
            --parking-dark: #121212;
            --parking-blue: #0d6efd; 
        }

        body {
            background-color: var(--parking-dark);
            color: #ffffff; 
            background-image: radial-gradient(circle at 2px 2px, #252525 1px, transparent 0);
            background-size: 40px 40px;
            font-family: 'Inter', sans-serif;
        }

        /* Card Style */
        .card-custom {
            background: var(--parking-black);
            border: none;
            border-radius: 12px;
            overflow: hidden;
        }

        .stat-card {
            border-left: 5px solid var(--parking-yellow);
            transition: transform 0.3s;
        }
        .stat-card:hover { transform: translateY(-5px); }

        /* Progress Bar */
        .progress { background-color: #333; height: 12px; border-radius: 10px; }
        .progress-bar { background-color: var(--parking-yellow); }

        /* Table Styling */
        .table-container {
            background-color: #ffffff; 
            border-radius: 8px;
            margin-top: 10px;
        }

        .table thead th {
            background-color: #f8f9fa !important;
            color: #333 !important;
            border-bottom: 3px solid var(--parking-yellow);
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 0.5px;
        }

        /* TEXT DALAM TABEL (HITAM) */
        .table tbody td {
            color: #000000 !important; 
            font-weight: 500;
            border-color: #eee;
        }

        /* ID TIKET (BIRU) */
        .text-tiket {
            color: var(--parking-blue) !important;
            font-family: 'Monaco', 'Consolas', monospace;
            font-weight: 700;
        }

        /* Plat Nomor */
        .badge-plat {
            background-color: var(--parking-yellow);
            color: #000 !important;
            font-weight: 800;
            padding: 4px 10px;
            border-radius: 4px;
            border: 1px solid #333;
            font-size: 0.9rem;
        }

        .parking-stripe {
            height: 8px;
            background: repeating-linear-gradient(-45deg, var(--parking-yellow), var(--parking-yellow) 10px, var(--parking-black) 10px, var(--parking-black) 20px);
        }
    </style>
</head>
<body>

<div class="container mt-4 pb-5">
    <div class="row mb-4 align-items-center">
        <div class="col-md-8">
            <h2 class="fw-bold"><i class="bi bi-speedometer2 me-2 text-warning"></i> Dashboard Admin</h2>
            <p class="text-white text-secondary">Selamat datang, <span class="text-white fw-bold"><?= $_SESSION['nama']; ?></span class="text-white">. Pantau aktivitas parkir Anda.</p>
        </div>
        <div class="col-md-4 text-md-end">
            <div class="badge bg-dark p-2 border border-secondary text-uppercase"><?= date('l, d M Y') ?></div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card card-custom stat-card shadow-sm p-4">
                <small class="text-white text-secondary text-uppercase">Total Pendapatan</small>
                <h2 class="text-white fw-bold mt-1">Rp <?= number_format($total_pendapatan, 0, ',', '.') ?></h2>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card card-custom stat-card shadow-sm p-4" style="border-left-color: #28a745;">
                <small class="text-white text-secondary text-uppercase">Kendaraan Parkir</small>
                <h2 class="text-white fw-bold mt-1"><?= $kendaraan_aktif ?> <span class="text-white fs-5 fw-normal text-secondary">Unit</span></h2>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card card-custom stat-card shadow-sm p-4" style="border-left-color: var(--parking-blue);">
                <small class="text-white text-secondary text-uppercase">Total User</small>
                <h2 class="text-white fw-bold mt-1"><?= $count_user ?> <span class="text-white fs-5 fw-normal text-secondary">Orang</span></h2>
            </div>
        </div>
    </div>

    <div class="card card-custom shadow-sm mb-4">
        <div class="card-header bg-transparent border-secondary py-3">
            <h6 class="mb-0 fw-bold"><i class="bi bi-geo-alt me-2"></i> Kapasitas Area Parkir</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <?php
                $areas = mysqli_query($conn, "SELECT * FROM tb_area");
                while($a = mysqli_fetch_assoc($areas)):
                    $persen = ($a['kapasitas'] > 0) ? ($a['terisi'] / $a['kapasitas']) * 100 : 0;
                    $status_color = ($persen >= 90) ? 'bg-danger' : 'bg-warning';
                ?>
                <div class="col-md-3 mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="small fw-bold text-white"><?= $a['nama_area'] ?></span>
                        <span class="small text-secondary"><?= $a['terisi'] ?>/<?= $a['kapasitas'] ?></span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar <?= $status_color ?>" role="progressbar" style="width: <?= $persen ?>%"></div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
        <div class="parking-stripe"></div>
    </div>

    <div class="card card-custom shadow-lg">
        <div class="card-header bg-transparent py-3 d-flex justify-content-between align-items-center">
            <h6 class="mb-0 fw-bold"><i class="bi bi-activity me-2 text-warning"></i> TRANSAKSI TERBARU</h6>
            <a href="laporan.php" class="btn btn-sm btn-outline-warning">Lihat Semua</a>
        </div>
        
        <div class="table-container shadow-sm mx-3 mb-3">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th class="ps-3">ID Tiket</th>
                            <th>No. Plat</th>
                            <th>Status</th>
                            <th>Waktu Masuk</th>
                            <th>Waktu Keluar</th>
                            <th class="text-end pe-3">Biaya</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $result = mysqli_query($conn, "SELECT * FROM tb_transaksi ORDER BY id_transaksi DESC LIMIT 10");
                        if(mysqli_num_rows($result) > 0):
                            while($row = mysqli_fetch_assoc($result)): 
                                $is_masuk = ($row['status'] == 'masuk');
                                $plat = $row['plat_nomor'] ?? $row['no_plat'] ?? '-';
                        ?>
                            <tr>
                                <td class="ps-3 text-tiket"><?= $row['kode_tiket'] ?? $row['id_transaksi'] ?></td>
                                <td><span class="badge-plat text-uppercase"><?= $plat ?></span></td>
                                <td>
                                    <?php if($is_masuk): ?>
                                        <span class="badge bg-success-subtle text-success border border-success px-2 py-1">MASUK</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger border border-danger px-2 py-1">KELUAR</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('d/m/Y | H:i', strtotime($row['waktu_masuk'])) ?></td>
                                <td><?= ($is_masuk || empty($row['waktu_keluar'])) ? '<span class="text-muted">-- : --</span>' : date('d/m/Y | H:i', strtotime($row['waktu_keluar'])) ?></td>
                                <td class="text-end pe-3 fw-bold">
                                    <?= $is_masuk ? '<span class="text-muted small">Pending</span>' : 'Rp ' . number_format($row['total_bayar'], 0, ',', '.') ?>
                                </td>
                            </tr>
                        <?php 
                            endwhile; 
                        else:
                        ?>
                            <tr><td colspan="6" class="text-center py-4 text-dark">Belum ada transaksi hari ini.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="parking-stripe"></div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>