<?php
// Set zona waktu PHP ke WIB
date_default_timezone_set('Asia/Jakarta');

$host = "localhost";
$user = "root";
$pass = "";
$db   = "parkir_db";

$conn = mysqli_connect($host, $user, $pass, $db);

// Set zona waktu MySQL agar CURDATE() dan NOW() juga WIB
mysqli_query($conn, "SET time_zone = '+07:00'");

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>