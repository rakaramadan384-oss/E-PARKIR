<?php
// Menampilkan error agar kita tahu salahnya di mana
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'config.php';
include_once 'notifikasi.php';

if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = mysqli_real_escape_string($conn, trim($_POST['username']));
    $password = trim($_POST['password']); 

    // Berdasarkan SQL kamu, password 'raka123' disimpan sebagai plain text
    $query = "SELECT * FROM tb_user WHERE username='$username' AND password='$password' AND status='aktif'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
        
        // Simpan ke Session
        $_SESSION['id_user']      = $data['id_user'];
        $_SESSION['username']      = $data['username'];
        $_SESSION['nama']         = $data['nama_lengkap'];
        $_SESSION['level']        = $data['level'];
        $_SESSION['status_login'] = true;

        // Redirect ke index.php
        header("Location: index.php");
        exit();
    } else {
        // Jika gagal, beri pesan yang jelas
        include 'notifikasi.php';
        showMessage('error', 'AKSES DITOLAK', 'Username atau Password salah!', 'login.php');
    }
} else {
    header("Location: login.php");
}
?>