<?php
session_start();
include 'config.php';
include_once 'notifikasi.php';

if (isset($_POST['submit_masuk'])) {
    $no_plat = mysqli_real_escape_string($conn, strtoupper($_POST['no_plat']));
    $jenis   = $_POST['jenis'];
    $id_area = $_POST['id_area'];
    $id_user = $_SESSION['id_user'];
    $kode_tiket = "PKR-" . date("YmdHis");
    $waktu_masuk = date("Y-m-d H:i:s");

    // 1. Simpan Kendaraan (Jika belum ada)
    mysqli_query($conn, "INSERT IGNORE INTO tb_kendaraan (no_plat, jenis_kendaraan) VALUES ('$no_plat', '$jenis')");
    $id_k = mysqli_insert_id($conn);
    if($id_k == 0){ // Jika sudah ada, ambil ID-nya
        $get_k = mysqli_query($conn, "SELECT id_kendaraan FROM tb_kendaraan WHERE no_plat='$no_plat'");
        $id_k = mysqli_fetch_assoc($get_k)['id_kendaraan'];
    }

    // 2. Simpan Transaksi
    $sql = "INSERT INTO tb_transaksi (kode_tiket, id_kendaraan, plat_nomor, id_area, id_petugas, waktu_masuk, status) 
            VALUES ('$kode_tiket', '$id_k', '$no_plat', '$id_area', '$id_user', '$waktu_masuk', 'masuk')";
    
    if (mysqli_query($conn, $sql)) {
        // 3. Update Kuota Area
        mysqli_query($conn, "UPDATE tb_area SET terisi = terisi + 1 WHERE id_area = '$id_area'");
        
        // 4. Redirect ke halaman cetak tiket
        include 'notifikasi.php';
            showMessage('success', 'TIKET DICETAK', 'Kendaraan berhasil masuk. Silakan cetak tiket.', 'petugas_input.php');
    } else {
        echo "Gagal: " . mysqli_error($conn);
    }
}
?>