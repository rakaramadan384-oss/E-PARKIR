<?php
session_start();
include 'config.php';
include_once 'notifikasi.php';

// Proteksi: Hanya petugas yang boleh masuk
if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'petugas_masuk') {
    header("Location: index.php");
    exit();
}

include 'header.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <style>
        :root {
            --parking-yellow: #ffcc00;
            --parking-black: #1a1a1a;
            --parking-dark: #121212;
            --parking-blue: #0d6efd; 
        }

        body {
            background-color: var(--parking-dark);
            color: #ffffff; 
            background-image: radial-gradient(circle at 2px 2px, #252525 1px, transparent 0);
            background-size: 40px 40px;
        }

        /* Card Statistik Area */
        .card-area {
            background: var(--parking-black);
            border: none;
            border-radius: 12px;
            transition: transform 0.3s;
        }
        .card-area:hover { transform: translateY(-5px); }

        /* Progress Bar Custom */
        .progress { background-color: #333; height: 8px; border-radius: 10px; }
        
        /* Card Utama Registrasi */
        .card-main {
            background: var(--parking-black);
            border: none;
            border-radius: 15px;
            overflow: hidden;
        }

        .card-header-custom {
            background: transparent;
            border-bottom: 1px solid #333;
            padding: 25px;
        }

        /* Input Styling */
        .form-label { color: var(--parking-yellow); letter-spacing: 1px; }
        
        .input-plat {
            background-color: #fff !important;
            color: #000 !important;
            border: 4px solid var(--parking-yellow) !important;
            font-family: 'Courier New', Courier, monospace;
            letter-spacing: 8px;
            text-shadow: 1px 1px 0px #ccc;
        }

        .form-select-custom {
            background-color: #2a2a2a !important;
            border: 1px solid #444 !important;
            color: #fff !important;
        }
        .form-select-custom:focus {
            border-color: var(--parking-yellow) !important;
            box-shadow: 0 0 0 0.25rem rgba(255, 204, 0, 0.2);
        }

        /* Tombol Cetak */
        .btn-submit {
            background-color: var(--parking-yellow);
            color: #000;
            border: none;
            font-weight: 900;
            letter-spacing: 2px;
            padding: 20px;
            transition: 0.3s;
        }
        .btn-submit:hover {
            background-color: #e6b800;
            transform: scale(1.02);
            color: #000;
        }

        .parking-stripe {
            height: 10px;
            background: repeating-linear-gradient(-45deg, var(--parking-yellow), var(--parking-yellow) 10px, var(--parking-black) 10px, var(--parking-black) 20px);
        }

        .badge-status {
            font-size: 0.7rem;
            padding: 5px 10px;
        }
    </style>
</head>
<body>

<div class="container mt-4 pb-5">
    <div class="row mb-4">
        <?php
        $res_area = mysqli_query($conn, "SELECT * FROM tb_area");
        while($row = mysqli_fetch_assoc($res_area)):
            $persen = ($row['kapasitas'] > 0) ? ($row['terisi'] / $row['kapasitas']) * 100 : 0;
            $progress_color = ($persen >= 100) ? 'bg-danger' : (($persen >= 80) ? 'bg-warning' : 'bg-success');
            $sisa = $row['kapasitas'] - $row['terisi'];
        ?>
        <div class="col-md-3 mb-3">
            <div class="card card-area shadow-sm">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h6 class="text-secondary text-uppercase small mb-1"><?= $row['nama_area'] ?></h6>
                            <h4 class="fw-bold mb-0 text-white"><?= $row['terisi'] ?> <small class="text-secondary fs-6">/ <?= $row['kapasitas'] ?></small></h4>
                        </div>
                        <span class="badge badge-status <?= $progress_color ?> text-uppercase"><?= round($persen) ?>%</span>
                    </div>
                    <div class="progress mt-3">
                        <div class="progress-bar <?= $progress_color ?>" style="width: <?= $persen ?>%"></div>
                    </div>
                    <small class="text-secondary mt-2 d-block">Sisa: <b class="text-white"><?= $sisa ?> Slot</b></small>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card card-main shadow-lg">
                <div class="card-header-custom text-center">
                    <h3 class="mb-0 fw-bold text-white"><i class="bi bi-qr-code-scan text-warning me-2"></i> REGISTRASI KENDARAAN</h3>
                    <p class="text-secondary small mb-0 mt-2">Pastikan plat nomor sesuai dengan fisik kendaraan</p>
                </div>
                
                <div class="card-body p-4 p-md-5">
                    <form action="proses_masuk.php" method="POST">
                        <div class="row">
                            <div class="col-md-12 mb-4">
                                <label class="form-label fw-bold"><i class="bi bi-card-text me-2"></i>NOMOR PLAT KENDARAAN</label>
                                <input type="text" name="no_plat" id="no_plat"
                                       class="form-control form-control-lg text-center fw-bold fs-1 text-uppercase input-plat" 
                                       placeholder="B 1234 ABC" 
                                       style="height: 100px;"
                                       oninput="this.value = this.value.toUpperCase()"
                                       required autofocus>
                            </div>
                            
                            <div class="col-md-6 mb-4">
                                <label class="form-label fw-bold"><i class="bi bi-bicycle me-2"></i>JENIS</label>
                                <select name="jenis" class="form-select form-select-lg form-select-custom" style="height: 60px;" required>
                                    <option value="" class="text-secondary">-- Pilih Jenis --</option>
                                    <option value="motor">🛵 MOTOR</option>
                                    <option value="mobil">🚗 MOBIL</option>
                                    <option value="truk">🚚 TRUK</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-4">
                                <label class="form-label fw-bold"><i class="bi bi-geo-alt me-2"></i>AREA PARKIR</label>
                                <select name="id_area" class="form-select form-select-lg form-select-custom" style="height: 60px;" required>
                                    <option value="">-- Pilih Lokasi --</option>
                                    <?php
                                    $areas = mysqli_query($conn, "SELECT * FROM tb_area WHERE status='aktif'");
                                    while($a = mysqli_fetch_assoc($areas)) {
                                        $sisa = $a['kapasitas'] - $a['terisi'];
                                        $disabled = ($sisa <= 0) ? 'disabled' : '';
                                        $label_sisa = ($sisa <= 0) ? '(PENUH)' : "(Sisa: $sisa)";
                                        echo "<option value='".$a['id_area']."' $disabled>".$a['nama_area']." $label_sisa</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mt-3">
                            <button type="submit" name="submit_masuk" class="btn btn-submit w-100 fs-4 shadow-lg">
                                <i class="bi bi-printer-fill me-2"></i> CETAK TIKET & MASUK
                            </button>
                        </div>
                    </form>
                </div>
                <div class="parking-stripe"></div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('no_plat').addEventListener('keyup', function(e) {
        this.value = this.value.toUpperCase();
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>