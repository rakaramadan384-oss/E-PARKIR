<?php
session_start();
include 'config.php';
include_once 'notifikasi.php';

// Proteksi halaman
if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'owner') {
    header("Location: index.php");
    exit();
}

include 'header.php';

$tgl_mulai = $_GET['tgl_mulai'] ?? '';
$tgl_selesai = $_GET['tgl_selesai'] ?? '';

$sql = "SELECT * FROM view_rekap_transaksi"; 
$where = " WHERE 1=1";

if (!empty($tgl_mulai) && !empty($tgl_selesai)) {
    $where .= " AND DATE(waktu_masuk) BETWEEN '$tgl_mulai' AND '$tgl_selesai'";
}

$sql .= $where . " ORDER BY status ASC, waktu_masuk DESC"; 
$result = mysqli_query($conn, $sql);

$q_total = mysqli_query($conn, "SELECT SUM(total_bayar) as grand_total FROM tb_transaksi" . $where . " AND status='keluar'");
$total = mysqli_fetch_assoc($q_total)['grand_total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <style>
        :root {
            --parking-yellow: #ffcc00;
            --parking-black: #1a1a1a;
            --parking-dark: #121212;
            --parking-green: #2ecc71;
        }

        body {
            background-color: var(--parking-dark);
            color: #ffffff; 
            background-image: radial-gradient(circle at 2px 2px, #252525 1px, transparent 0);
            background-size: 40px 40px;
        }

        .card-custom {
            background: var(--parking-black);
            border: none;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 20px;
        }

        /* Omzet Widget */
        .omzet-box {
            background: linear-gradient(135deg, var(--parking-black) 0%, #252525 100%);
            border-left: 5px solid var(--parking-yellow);
            padding: 20px;
            border-radius: 10px;
        }

        /* Form Filter */
        .form-control-dark {
            background-color: #2a2a2a !important;
            border: 1px solid #444 !important;
            color: #fff !important;
        }
        .form-control-dark:focus {
            border-color: var(--parking-yellow) !important;
            box-shadow: 0 0 0 0.25rem rgba(255, 204, 0, 0.2);
        }

        /* Tabel Laporan */
        .table-container {
            background-color: #ffffff; 
            border-radius: 10px;
            overflow: hidden;
            margin-top: 10px;
        }

        .table thead th {
            background-color: #f8f9fa !important;
            color: #333 !important;
            border-bottom: 3px solid var(--parking-yellow);
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 1px;
            padding: 15px;
        }

        .table tbody td {
            color: #000000 !important;
            font-weight: 500;
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }

        /* Row Alternatif untuk Kendaraan Masuk */
        .row-masuk { background-color: #fff9e6 !important; }

        .parking-stripe {
            height: 10px;
            background: repeating-linear-gradient(-45deg, var(--parking-yellow), var(--parking-yellow) 10px, var(--parking-black) 10px, var(--parking-black) 20px);
        }

        @media print {
            .btn, form, .parking-stripe { display: none !important; }
            body { background: white; color: black; }
            .table-container { box-shadow: none; border: 1px solid #000; }
        }
    </style>
</head>
<body>

<div class="container mt-4 pb-5">
    <div class="row mb-4 align-items-center">
        <div class="col-md-7">
            <h2 class="fw-bold text-white"><i class="bi bi-file-earmark-bar-graph text-warning me-2"></i> LAPORAN REKAPITULASI</h2>
            <h4 id="jam_realtime" class="text-warning fw-bold">00:00:00 WIB</h4>
            <p class="text-secondary mb-0">
                <i class="bi bi-calendar3 me-1"></i> Periode: 
                <span class="text-white"><?= (!empty($tgl_mulai)) ? date('d M Y', strtotime($tgl_mulai))." - ".date('d M Y', strtotime($tgl_selesai)) : 'Semua Waktu' ?></span>
            </p>
        </div>
        <div class="col-md-5">
            <div class="omzet-box shadow-lg float-md-end w-100 w-md-auto">
                <small class="text-secondary d-block text-uppercase fw-bold" style="font-size: 0.7rem; letter-spacing: 1px;">Omzet Selesai (Terfilter)</small>
                <h2 class="mb-0 text-warning fw-black">Rp <?= number_format($total, 0, ',', '.') ?></h2>
            </div>
        </div>
    </div>

    <div class="card card-custom shadow-sm">
        <div class="card-body p-4">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-warning">DARI TANGGAL</label>
                    <input type="date" name="tgl_mulai" class="form-control form-control-dark" value="<?= $tgl_mulai ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-warning">SAMPAI TANGGAL</label>
                    <input type="date" name="tgl_selesai" class="form-control form-control-dark" value="<?= $tgl_selesai ?>" required>
                </div>
                <div class="col-md-6 d-flex gap-2">
                    <button type="submit" class="btn btn-warning flex-grow-1 fw-bold">
                        <i class="bi bi-filter"></i> FILTER
                    </button>
                    <a href="owner_laporan.php" class="btn btn-outline-secondary">RESET</a>
                    <button type="button" onclick="exportToExcel()" class="btn btn-success fw-bold">
                        <i class="bi bi-file-earmark-excel"></i> EXCEL
                    </button>
                    <button type="button" onclick="window.print()" class="btn btn-light">
                        <i class="bi bi-printer"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div class="card card-custom">
        <div class="parking-stripe"></div>
        <div class="card-body p-0">
            <div class="table-container">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tabelLaporan">
                        <thead>
                            <tr>
                                <th class="ps-4">Tiket</th>
                                <th>No. Plat</th>
                                <th>Jenis</th>
                                <th>Status</th>
                                <th>Waktu Masuk</th>
                                <th>Waktu Keluar</th>
                                <th>Durasi</th>
                                <th class="text-end pe-4">Biaya</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(mysqli_num_rows($result) > 0): ?>
                                <?php while($row = mysqli_fetch_assoc($result)): 
                                    $is_masuk = ($row['status'] == 'masuk');
                                ?>
                                <tr class="<?= $is_masuk ? 'row-masuk' : '' ?>">
                                    <td class="ps-4 fw-bold text-primary"><?= $row['kode_tiket'] ?></td>
                                    <td><span class="badge bg-dark text-white border border-secondary px-2 py-1"><?= $row['no_plat'] ?></span></td>
                                    <td><?= ucfirst($row['jenis_kendaraan']) ?></td>
                                    <td>
                                        <?php if($is_masuk): ?>
                                            <span class="badge bg-warning text-dark"><i class="bi bi-clock-history"></i> PARKIR</span>
                                        <?php else: ?>
                                            <span class="badge bg-success text-white"><i class="bi bi-check-circle"></i> SELESAI</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="small"><?= date('d/m/y H:i', strtotime($row['waktu_masuk'])) ?></td>
                                    <td class="small">
                                        <?= $is_masuk ? '<span class="text-muted">--:--</span>' : date('d/m/y H:i', strtotime($row['waktu_keluar'])) ?>
                                    </td>
                                    <td><?= $is_masuk ? '-' : $row['durasi_jam'] . ' Jam' ?></td>
                                    <td class="text-end pe-4 fw-bold <?= $is_masuk ? 'text-muted' : 'text-success' ?>">
                                        <?= $is_masuk ? '<i>Pending</i>' : 'Rp ' . number_format($row['total_bayar'], 0, ',', '.') ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="8" class="text-center py-5 text-muted">Belum ada data pada periode ini.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="parking-stripe"></div>
    </div>
</div>

<script>
function updateJam() {
    const now = new Date();
    const options = { timeZone: 'Asia/Jakarta', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' };
    const jamString = now.toLocaleTimeString('id-ID', options);
    document.getElementById('jam_realtime').innerText = jamString + " WIB";
}
setInterval(updateJam, 1000);
updateJam();

function exportToExcel() {
    const table = document.getElementById("tabelLaporan");
    let html = table.outerHTML;
    const uri = 'data:application/vnd.ms-excel;base64,';
    const template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><meta charset="UTF-8"></head><body>{table}</body></html>';
    const base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) };
    const format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) };

    const ctx = { table: html };
    const link = document.createElement("a");
    link.href = uri + base64(format(template, ctx));
    link.download = "Laporan_Parkir_<?= date('Y-m-d') ?>.xls";
    link.click();
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>