<?php
session_start();
include 'config.php';
include_once 'notifikasi.php';

// Proteksi halaman: Hanya admin yang boleh masuk
if (!isset($_SESSION['level']) || $_SESSION['level'] !== 'admin') {
    header("Location: index.php");
    exit();
}

include 'header.php';

// Logika Tambah User
if(isset($_POST['tambah'])){
    $nama     = mysqli_real_escape_string($conn, $_POST['nama']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']); 
    $level    = mysqli_real_escape_string($conn, $_POST['level']);

    $query = "INSERT INTO tb_user (nama_lengkap, username, password, level, status) 
              VALUES ('$nama', '$username', '$password', '$level', 'aktif')";
    
    if(mysqli_query($conn, $query)){
        include 'notifikasi.php';
            showMessage('success', 'USER DITAMBAH', 'Data user baru telah tersimpan di sistem.', 'admin_user.php');
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <style>
        :root {
            --parking-yellow: #ffcc00;
            --parking-black: #1a1a1a;
            --parking-dark: #121212;
        }

        body {
            background-color: var(--parking-dark);
            color: #ffffff; 
            background-image: radial-gradient(circle at 2px 2px, #252525 1px, transparent 0);
            background-size: 40px 40px;
        }

        .card-custom {
            background: var(--parking-black);
            border: none;
            border-radius: 12px;
            overflow: hidden;
        }

        /* Container Tabel Putih Kontras */
        .table-container {
            background-color: #ffffff; 
            border-radius: 10px;
            overflow: hidden;
            margin-top: 15px;
        }

        .table thead th {
            background-color: #f8f9fa !important;
            color: #333 !important;
            border-bottom: 3px solid var(--parking-yellow);
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 1px;
            padding: 15px;
        }

        .table tbody td {
            color: #000000 !important;
            font-weight: 500;
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }

        /* Badge Level Custom */
        .badge-level {
            font-weight: 800;
            padding: 5px 12px;
            text-transform: uppercase;
            font-size: 0.7rem;
        }

        /* Form Modal Styling */
        .modal-content {
            background-color: var(--parking-black);
            color: #fff;
            border: 1px solid #333;
        }
        .modal-header { border-bottom: 1px solid #333; }
        .form-control-dark {
            background-color: #252525 !important;
            border: 1px solid #444 !important;
            color: #fff !important;
        }
        .form-control-dark:focus {
            border-color: var(--parking-yellow) !important;
            box-shadow: 0 0 0 0.25rem rgba(255, 204, 0, 0.25);
        }

        .parking-stripe {
            height: 10px;
            background: repeating-linear-gradient(-45deg, var(--parking-yellow), var(--parking-yellow) 10px, var(--parking-black) 10px, var(--parking-black) 20px);
        }

        .btn-yellow {
            background-color: var(--parking-yellow);
            color: #000;
            font-weight: bold;
        }
        .btn-yellow:hover {
            background-color: #e6b800;
            color: #000;
        }
    </style>
</head>
<body>

<div class="container mt-4 pb-5">
    <div class="row mb-4 align-items-center">
        <div class="col-md-7">
            <h2 class="fw-bold"><i class="bi bi-people-fill text-warning me-2"></i> DATA PENGGUNA</h2>
            <p class="text-secondary">Kelola akun Admin, Petugas, dan Owner dalam satu sistem.</p>
        </div>
        <div class="col-md-5 text-md-end">
            <button class="btn btn-yellow px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#modalTambah">
                <i class="bi bi-person-plus-fill me-2"></i> TAMBAH USER
            </button>
        </div>
    </div>

    <div class="card card-custom shadow-lg">
        <div class="parking-stripe"></div>
        <div class="card-body p-4">
            <div class="table-container">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead>
                            <tr>
                                <th class="ps-4">Nama Lengkap</th>
                                <th>Username</th>
                                <th>Hak Akses</th>
                                <th>Status</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = mysqli_query($conn, "SELECT * FROM tb_user ORDER BY level ASC");
                            while($u = mysqli_fetch_assoc($res)):
                                // Logika Warna Badge
                                $badge_bg = 'bg-secondary';
                                if($u['level'] == 'admin') $badge_bg = 'bg-danger';
                                if($u['level'] == 'owner') $badge_bg = 'bg-primary';
                                if($u['level'] == 'petugas') $badge_bg = 'bg-info text-dark';
                            ?>
                            <tr>
                                <td class="ps-4">
                                    <span class="fw-bold d-block"><?= $u['nama_lengkap'] ?></span>
                                    <small class="text-muted">UID: #00<?= $u['id_user'] ?></small>
                                </td>
                                <td><code class="bg-light px-2 py-1 text-dark rounded"><?= $u['username'] ?></code></td>
                                <td><span class="badge <?= $badge_bg ?> badge-level"><?= $u['level'] ?></span></td>
                                <td>
                                    <span class="text-success"><i class="bi bi-check-circle-fill me-1"></i> <?= ucfirst($u['status']) ?></span>
                                </td>
                                <td class="text-center">
                                    <a href="admin_user_hapus.php?id=<?= $u['id_user'] ?>" 
                                       class="btn btn-outline-danger btn-sm px-3" 
                                       onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?')">
                                        <i class="bi bi-trash3 me-1"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="parking-stripe"></div>
    </div>
</div>

<div class="modal fade" id="modalTambah" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content shadow-lg" method="POST">
      <div class="modal-header">
          <h5 class="modal-title fw-bold text-warning"><i class="bi bi-person-plus me-2"></i>Registrasi User Baru</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-4">
          <div class="mb-3">
              <label class="form-label small fw-bold">NAMA LENGKAP</label>
              <input type="text" name="nama" class="form-control form-control-dark" placeholder="Masukkan nama asli" required>
          </div>
          <div class="mb-3">
              <label class="form-label small fw-bold">USERNAME</label>
              <input type="text" name="username" class="form-control form-control-dark" placeholder="Username untuk login" required>
          </div>
          <div class="mb-3">
              <label class="form-label small fw-bold">PASSWORD</label>
              <input type="password" name="password" class="form-control form-control-dark" placeholder="Minimal 6 karakter" required>
          </div>
          <div class="mb-2">
              <label class="form-label small fw-bold">LEVEL AKSES</label>
              <select name="level" class="form-select form-control-dark">
                  <option value="petugas_masuk">Petugas Masuk</option>
                  <option value="petugas_keluar">Petugas Keluar</option>
                  <option value="owner">Owner</option>
                  <option value="admin">Admin</option>
              </select>
          </div>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" name="tambah" class="btn btn-yellow px-4">SIMPAN DATA</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>